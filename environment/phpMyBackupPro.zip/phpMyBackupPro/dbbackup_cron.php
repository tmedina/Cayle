<?php
// This code was created by phpMyBackupPro v.2.1 
// http://www.phpMyBackupPro.net
$_POST['db']=array("nucis_space_tables_prod", );
$_POST['tables']="on";
$_POST['data']="on";
$_POST['drop']="on";
$_POST['zip']="zip";
$period=(3600*24)*0;
$security_key="d730d74f16585bd586d16b74b1d84639";
// This is the relative path to the phpMyBackupPro v.2.1 directory
@chdir("C:/xampp/htdocs/phpmybackuppro/");
@include("backup.php");
?>
